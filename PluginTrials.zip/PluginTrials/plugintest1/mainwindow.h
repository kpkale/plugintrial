#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtCore>
#include <QMessageBox>
#include <QDebug>
#include "myechointerface.h"
#include "newtestingclass.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();


private slots:
    void sendEcho();

    void on_lineEdit_textEdited(const QString &arg1);

    void on_pushButton_clicked();

    void Receivedmessage(QString mesg1);

private:
    bool loadPlugin();

    Ui::MainWindow *ui;
    Myechointerface *myechoint;
};

#endif // MAINWINDOW_H
