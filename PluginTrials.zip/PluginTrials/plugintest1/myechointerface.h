#ifndef MYECHOINTERFACE_H
#define MYECHOINTERFACE_H

#include <QString>
#include "newtestingclass.h"

class Myechointerface
{
public:
    virtual ~Myechointerface(){}
    virtual void mygastro(const QString &message) = 0;
    virtual void Settextvalue(const QString &value)=0;
//    virtual mytesting(const NewTestingClass *mytest) = 0;

signals:
    virtual void MyReturnString(QString mystring)=0;

public slots:
};


QT_BEGIN_NAMESPACE

#define MyechoInterface_iid "it.stamp.MyEchoInterface"

Q_DECLARE_INTERFACE(Myechointerface, MyechoInterface_iid)
QT_END_NAMESPACE

#endif // MYECHOINTERFACE_H
