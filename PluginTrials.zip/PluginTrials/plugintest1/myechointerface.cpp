#include "myechointerface.h"

QString Myechointerface::myecho(const QString &message)
{

}
