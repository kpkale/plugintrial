#ifndef NEWTESTINGCLASS_H
#define NEWTESTINGCLASS_H

#include <QObject>

class NewTestingClass : public QObject
{
    Q_OBJECT

    Q_PROPERTY(qreal DotDistance READ DotDistance WRITE SetDotDistance)
    Q_PROPERTY(int DotRepeat READ DotRepeat WRITE SetDotRepeat)
    Q_PROPERTY(bool FalseOrigin READ FalseOrigin WRITE SetFalseOrigin)
    Q_PROPERTY(qreal XOrigin READ XOrigin WRITE SetOriginX)
    Q_PROPERTY(qreal YOrigin READ YOrigin WRITE SetOriginY)
    Q_PROPERTY(qreal ZOrigin READ ZOrigin WRITE SetOriginZ)

public:
    explicit NewTestingClass(QObject *parent = nullptr);

public slots:
    void SetDotDistance(qreal value) {dotdistance = value;}
    qreal DotDistance(){return dotdistance;}

    void SetDotRepeat(int value) {dotrepeat = value;}
    int DotRepeat(){return dotrepeat;}

    void SetFalseOrigin(bool value) {falseorigin = value;}
    bool FalseOrigin(){return falseorigin;}

    void SetOriginX(qreal value){originx = value;}
    qreal XOrigin(){return originx;}

    void SetOriginY(qreal value){originy = value;}
    qreal YOrigin(){return originy;}

    void SetOriginZ(qreal value){originz = value;}
    qreal ZOrigin(){return originz;}

    void TriggerItem();

signals:
    void ItemChanged();

private:
    qreal       dotdistance;
    int         dotrepeat;
    bool        falseorigin;
    qreal       originx;
    qreal       originy;
    qreal       originz;
};

#endif // NEWTESTINGCLASS_H
