#include "newtestingclass.h"

NewTestingClass::NewTestingClass(QObject *parent) : QObject(parent)
{

}

void NewTestingClass::TriggerItem()
{
    emit ItemChanged();
}
