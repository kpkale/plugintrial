#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    if (!loadPlugin()) {
        QMessageBox::information(this, "Error", "Could not load the plugin");
        ui->lineEdit->setEnabled(false);
        ui->pushButton->setEnabled(false);
    }

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::sendEcho()
{
    myechoint->mygastro(ui->lineEdit->text());
//    ui->lbl_message->setText(text);
}

bool MainWindow::loadPlugin()
{
    QDir pluginsDir(qApp->applicationDirPath());
#if defined(Q_OS_WIN)
    if (pluginsDir.dirName().toLower() == "debug" || pluginsDir.dirName().toLower() == "release")
    {
        pluginsDir.cdUp();
        pluginsDir.cdUp();
    }
#elif defined(Q_OS_MAC)
    if (pluginsDir.dirName() == "MacOS") {
        pluginsDir.cdUp();
        pluginsDir.cdUp();
        pluginsDir.cdUp();
    }
#endif
    pluginsDir.cd("plugins");
    qDebug()<<pluginsDir.path();
    foreach (QString fileName, pluginsDir.entryList(QDir::Files)) {
        QPluginLoader pluginLoader(pluginsDir.absoluteFilePath(fileName));
        QObject *plugin = pluginLoader.instance();
        if (plugin) {
            myechoint = qobject_cast<Myechointerface *>(plugin);
            if (myechoint)
            {
                connect(dynamic_cast<QObject*>(myechoint),SIGNAL(MyReturnString(QString)),this,SLOT(Receivedmessage(QString)));
                return true;
            }
        }
    }

    return false;
}

void MainWindow::on_lineEdit_textEdited(const QString &arg1)
{
}

void MainWindow::on_pushButton_clicked()
{
    sendEcho();
}

void MainWindow::Receivedmessage(QString mesg1)
{
    ui->lbl_message->setText(mesg1);
    myechoint->mygastro(ui->lbl_message->text());

}

