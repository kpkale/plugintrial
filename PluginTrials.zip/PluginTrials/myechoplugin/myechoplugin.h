#ifndef MYECHOPLUGIN_H
#define MYECHOPLUGIN_H

#include <QObject>
#include <QtPlugin>
#include "myechoplugin_global.h"
#include "myechointerface.h"
#include "plugtestdialog.h"

class MYECHOPLUGINSHARED_EXPORT Myechoplugin : public QObject, public Myechointerface
//class Myechoplugin : public QObject,Myechointerface
{
    Q_OBJECT
    Q_PLUGIN_METADATA(IID "it.stamp.MyEchoInterface" FILE "myechoplugin.json")
    Q_INTERFACES(Myechointerface)

public:
    void mygastro(const QString &message) override;    //Q_DECL_OVERRIDE
    void Settextvalue(const QString &value) override;

signals:
    void MyReturnString(QString mystring);

public slots:
    void TinkerValue(QString value);

private:
    plugtestdialog *mydiag;
//    Myechoplugin();
};

#endif // MYECHOPLUGIN_H
