#include <QtWidgets>
#include "myechoplugin.h"


void Myechoplugin::mygastro(const QString &message)
{
    mydiag = new plugtestdialog();
    connect(mydiag,SIGNAL(TinkerValue(QString)),this,SLOT(TinkerValue(QString)));
    mydiag->Setvalues(message);
    mydiag->show();
//    QString retmessage = mydiag->newvalue;
//    mydiag->close();
//    mydiag->deleteLater();
    //    return retmessage;
}

void Myechoplugin::Settextvalue(const QString &value)
{
    if(mydiag)
        mydiag->Setvalues(value);
}

void Myechoplugin::TinkerValue(QString value)
{
    emit MyReturnString(value);
}

//Q_EXPORT_PLUGIN2(Myechoplugin,Myechoplugin);
//Myechoplugin::Myechoplugin()
//{
//}
