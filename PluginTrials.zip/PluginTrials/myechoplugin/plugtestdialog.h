#ifndef PLUGTESTDIALOG_H
#define PLUGTESTDIALOG_H

#include <QDialog>

namespace Ui {
class plugtestdialog;
}

class plugtestdialog : public QDialog
{
    Q_OBJECT

public:
    explicit plugtestdialog(QWidget *parent = 0);
    ~plugtestdialog();
    void Setvalues(QString value);
    QString newvalue;

public slots:

private slots:
    void on_pushButton_clicked();

signals:
    void TinkerValue(QString value);

private:
    Ui::plugtestdialog *ui;
};

#endif // PLUGTESTDIALOG_H
