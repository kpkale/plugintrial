#include "plugtestdialog.h"
#include "ui_plugtestdialog.h"

plugtestdialog::plugtestdialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::plugtestdialog)
{
    ui->setupUi(this);
}

plugtestdialog::~plugtestdialog()
{
    delete ui;
}

void plugtestdialog::Setvalues(QString value)
{
    ui->txt_recd->setText(value);
}

void plugtestdialog::on_pushButton_clicked()
{
    newvalue = ui->txt_send->text();
    emit TinkerValue(newvalue);
//    this->hide();
}
